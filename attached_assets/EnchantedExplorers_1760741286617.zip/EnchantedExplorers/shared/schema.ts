import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - Required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - Required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// CV Data table - Stores comprehensive CV information
export const cvData = pgTable("cv_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  
  // Personal Information
  fullName: varchar("full_name").notNull(),
  email: varchar("email").notNull(),
  phone: varchar("phone").notNull(),
  location: varchar("location"),
  website: varchar("website"),
  linkedin: varchar("linkedin"),
  github: varchar("github"),
  
  // Professional Summary
  summary: text("summary"),
  
  // Arrays stored as JSONB
  workExperience: jsonb("work_experience").$type<WorkExperience[]>().default([]),
  education: jsonb("education").$type<Education[]>().default([]),
  skills: jsonb("skills").$type<string[]>().default([]),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type CVData = typeof cvData.$inferSelect;

export const insertCVDataSchema = createInsertSchema(cvData).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Valid phone number is required"),
});

export type InsertCVData = z.infer<typeof insertCVDataSchema>;

// Work Experience type
export interface WorkExperience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

// Education type
export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  current: boolean;
}

// Orders table - Tracks CV generation orders
export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  cvDataId: varchar("cv_data_id").notNull().references(() => cvData.id, { onDelete: 'cascade' }),
  
  packageType: varchar("package_type").notNull(), // 'basic', 'standard', 'premium'
  amount: integer("amount").notNull(), // Amount in cents
  currency: varchar("currency").notNull().default('GHS'),
  
  // Paystack payment details
  paystackReference: varchar("paystack_reference").unique(),
  paymentStatus: varchar("payment_status").notNull().default('pending'), // 'pending', 'success', 'failed'
  
  // CV generation status
  generationStatus: varchar("generation_status").notNull().default('pending'), // 'pending', 'processing', 'completed', 'failed'
  
  // Generated CV data
  optimizedContent: jsonb("optimized_content"),
  selectedTemplate: varchar("selected_template"),
  cvFileUrl: varchar("cv_file_url"),
  coverLetterFileUrl: varchar("cover_letter_file_url"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type Order = typeof orders.$inferSelect;

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  paystackReference: true,
  paymentStatus: true,
  generationStatus: true,
  optimizedContent: true,
  cvFileUrl: true,
  coverLetterFileUrl: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;

// CV Templates - Predefined templates
export const templates = pgTable("templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  previewImage: varchar("preview_image"),
  category: varchar("category").notNull(), // 'professional', 'creative', 'modern', 'classic'
  isActive: varchar("is_active").notNull().default('true'),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Template = typeof templates.$inferSelect;

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
});

export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
