import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, FileText, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

const templates = [
  {
    id: "modern-professional",
    name: "Modern Professional",
    category: "professional",
    description: "Clean and contemporary design perfect for corporate roles",
  },
  {
    id: "classic-executive",
    name: "Classic Executive",
    category: "classic",
    description: "Traditional layout ideal for senior positions",
  },
  {
    id: "creative-designer",
    name: "Creative Designer",
    category: "creative",
    description: "Bold and unique design for creative professionals",
  },
  {
    id: "tech-specialist",
    name: "Tech Specialist",
    category: "modern",
    description: "Technical-focused layout with clear sections",
  },
  {
    id: "academic-scholar",
    name: "Academic Scholar",
    category: "classic",
    description: "Research-oriented format for academic positions",
  },
  {
    id: "business-leader",
    name: "Business Leader",
    category: "professional",
    description: "Executive-level design showcasing leadership",
  },
];

export default function Templates() {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [, navigate] = useLocation();

  const handleContinue = () => {
    if (selectedTemplate) {
      localStorage.setItem("selectedTemplate", selectedTemplate);
      navigate("/checkout");
    }
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="mb-12 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Choose Your Template</h1>
              <p className="text-muted-foreground">Select a professional template that best represents your style</p>
            </div>
            {selectedTemplate && (
              <Button onClick={handleContinue} size="lg" data-testid="button-continue">
                Continue to Checkout
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <Card
              key={template.id}
              className={`overflow-hidden cursor-pointer transition-all ${
                selectedTemplate === template.id
                  ? "ring-2 ring-primary shadow-lg"
                  : "hover-elevate"
              }`}
              onClick={() => setSelectedTemplate(template.id)}
              data-testid={`card-template-${template.id}`}
            >
              <div className="aspect-[3/4] bg-muted relative flex items-center justify-center">
                <FileText className="w-16 h-16 text-muted-foreground" />
                {selectedTemplate === template.id && (
                  <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-5 h-5 text-primary-foreground" />
                  </div>
                )}
              </div>
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{template.name}</h3>
                  <Badge variant="secondary" className="text-xs">
                    {template.category}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{template.description}</p>
              </div>
            </Card>
          ))}
        </div>

        {!selectedTemplate && (
          <div className="mt-12 text-center">
            <p className="text-muted-foreground">Select a template to continue</p>
          </div>
        )}
      </div>
    </div>
  );
}
