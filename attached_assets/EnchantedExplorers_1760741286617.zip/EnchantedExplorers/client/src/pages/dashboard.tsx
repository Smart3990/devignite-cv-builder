import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { FileText, Download, Plus, Clock, CheckCircle, XCircle } from "lucide-react";
import { useLocation } from "wouter";
import type { Order } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: !!user,
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [user, authLoading, toast]);

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "processing":
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>;
      case "processing":
        return <Badge className="bg-yellow-500">Processing</Badge>;
      case "failed":
        return <Badge variant="destructive">Failed</Badge>;
      default:
        return <Badge variant="outline">Pending</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <h1 className="text-xl font-bold">My Dashboard</h1>
          <div className="flex items-center gap-3">
            <Button onClick={() => navigate("/create-cv")} data-testid="button-create-new">
              <Plus className="w-4 h-4 mr-1" />
              Create New CV
            </Button>
            <Button variant="ghost" asChild data-testid="button-logout">
              <a href="/api/logout">Logout</a>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-12">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">
            Welcome back, {user?.firstName || user?.email}!
          </h2>
          <p className="text-muted-foreground">Manage your CVs and track your orders</p>
        </div>

        {/* Orders List */}
        <div className="space-y-6">
          <h3 className="text-xl font-semibold">Your Orders</h3>
          
          {!orders || orders.length === 0 ? (
            <Card className="p-12 text-center">
              <FileText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No CVs yet</h3>
              <p className="text-muted-foreground mb-6">
                Start creating your professional CV today
              </p>
              <Button onClick={() => navigate("/create-cv")} data-testid="button-start-creating">
                <Plus className="w-4 h-4 mr-1" />
                Create Your First CV
              </Button>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {orders.map((order, index) => (
                <Card key={order.id} className="p-6 space-y-4 hover-elevate" data-testid={`card-order-${index}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(order.generationStatus)}
                      <div>
                        <h4 className="font-semibold">
                          {order.packageType.charAt(0).toUpperCase() + order.packageType.slice(1)} Package
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {new Date(order.createdAt!).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    {getStatusBadge(order.generationStatus)}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div>
                      <p className="text-sm text-muted-foreground">Amount Paid</p>
                      <p className="font-semibold">
                        GH₵{(order.amount / 100).toFixed(2)}
                      </p>
                    </div>
                    {order.generationStatus === "completed" && order.cvFileUrl && (
                      <Button size="sm" data-testid={`button-download-${index}`}>
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    )}
                  </div>

                  {order.generationStatus === "processing" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Generating your CV...</span>
                        <span className="font-medium">~2 minutes</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary animate-pulse" style={{ width: "60%" }} />
                      </div>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
