import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles, FileText, Zap, Shield, Users } from "lucide-react";
import logoUrl from "@assets/devi-removebg-preview (1)_1760738792150.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={logoUrl} alt="Devignite" className="h-10 w-10" />
            <span className="text-xl font-bold">Devignite</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#how-it-works" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-how-it-works">How It Works</a>
            <a href="#templates" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-templates">Templates</a>
            <a href="#pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing">Pricing</a>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild data-testid="button-login">
              <a href="/api/login">Log In</a>
            </Button>
            <Button asChild data-testid="button-get-started">
              <a href="/api/login">Get Started</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        <div className="relative max-w-7xl mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <Badge className="mx-auto" data-testid="badge-ai-powered">
              <Sparkles className="w-3 h-3 mr-1" />
              AI-Powered CV Builder
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Create Your Professional CV in Minutes
            </h1>
            <p className="text-xl text-muted-foreground">
              Build ATS-optimized resumes that get you noticed. Our AI technology ensures your CV stands out from the competition.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild data-testid="button-hero-start">
                <a href="/api/login">Start Building Now</a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-hero-templates">
                <a href="#templates">View Templates</a>
              </Button>
            </div>
            <div className="flex items-center justify-center gap-8 pt-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-primary" />
                <span>ATS Optimized</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-primary" />
                <span>AI Enhanced</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-primary" />
                <span>Fast Delivery</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 md:py-32 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">How It Works</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Four simple steps to create your professional CV
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="p-6 space-y-4 hover-elevate" data-testid="card-step-1">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">1. Fill Your Details</h3>
              <p className="text-muted-foreground">
                Complete our guided form with your professional information, work experience, and skills.
              </p>
            </Card>
            <Card className="p-6 space-y-4 hover-elevate" data-testid="card-step-2">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">2. Choose Template</h3>
              <p className="text-muted-foreground">
                Select from our collection of professional, ATS-optimized CV templates.
              </p>
            </Card>
            <Card className="p-6 space-y-4 hover-elevate" data-testid="card-step-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">3. AI Optimization</h3>
              <p className="text-muted-foreground">
                Our AI polishes your content, ensuring perfect formatting and ATS compatibility.
              </p>
            </Card>
            <Card className="p-6 space-y-4 hover-elevate" data-testid="card-step-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">4. Download & Apply</h3>
              <p className="text-muted-foreground">
                Receive your professional CV via email within minutes. Ready to impress employers.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Templates Preview */}
      <section id="templates" className="py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Professional Templates</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose from our curated collection of ATS-optimized templates
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {['Modern Professional', 'Classic Executive', 'Creative Designer', 'Tech Specialist', 'Academic Scholar', 'Business Leader'].map((name, i) => (
              <Card key={i} className="overflow-hidden group hover-elevate" data-testid={`card-template-${i}`}>
                <div className="aspect-[3/4] bg-muted flex items-center justify-center">
                  <FileText className="w-16 h-16 text-muted-foreground" />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold">{name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">Professional & ATS-friendly</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 md:py-32 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">Simple, Transparent Pricing</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose the package that fits your needs
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="p-8 space-y-6 hover-elevate" data-testid="card-pricing-basic">
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Basic CV</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold">GH₵50</span>
                </div>
                <p className="text-sm text-muted-foreground">Perfect for getting started</p>
              </div>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Professional CV</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">AI Content Optimization</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">ATS-Optimized</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Email Delivery</span>
                </li>
              </ul>
              <Button className="w-full" variant="outline" asChild data-testid="button-pricing-basic">
                <a href="/api/login">Get Started</a>
              </Button>
            </Card>

            <Card className="p-8 space-y-6 border-primary relative hover-elevate" data-testid="card-pricing-standard">
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2" data-testid="badge-most-popular">Most Popular</Badge>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">CV + Cover Letter</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold">GH₵80</span>
                </div>
                <p className="text-sm text-muted-foreground">Complete application package</p>
              </div>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Professional CV</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Custom Cover Letter</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">AI Content Optimization</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Priority Support</span>
                </li>
              </ul>
              <Button className="w-full" asChild data-testid="button-pricing-standard">
                <a href="/api/login">Get Started</a>
              </Button>
            </Card>

            <Card className="p-8 space-y-6 hover-elevate" data-testid="card-pricing-premium">
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Premium Package</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold">GH₵120</span>
                </div>
                <p className="text-sm text-muted-foreground">Everything you need to succeed</p>
              </div>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Professional CV</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Custom Cover Letter</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">LinkedIn Profile Optimization</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary" />
                  <span className="text-sm">Unlimited Revisions (7 days)</span>
                </li>
              </ul>
              <Button className="w-full" variant="outline" asChild data-testid="button-pricing-premium">
                <a href="/api/login">Get Started</a>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-3 gap-12 text-center">
            <div className="space-y-3">
              <div className="text-4xl font-bold text-primary">10,000+</div>
              <div className="text-muted-foreground">CVs Created</div>
            </div>
            <div className="space-y-3">
              <div className="text-4xl font-bold text-primary">95%</div>
              <div className="text-muted-foreground">Success Rate</div>
            </div>
            <div className="space-y-3">
              <div className="text-4xl font-bold text-primary">3-5 Min</div>
              <div className="text-muted-foreground">Delivery Time</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src={logoUrl} alt="Devignite" className="h-8 w-8" />
              <span className="font-bold">Devignite</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 Devignite. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
