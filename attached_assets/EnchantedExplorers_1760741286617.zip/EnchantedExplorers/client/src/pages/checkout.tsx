import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Shield, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const packages = [
  {
    id: "basic",
    name: "Basic CV",
    price: 50,
    features: [
      "Professional CV",
      "AI Content Optimization",
      "ATS-Optimized",
      "Email Delivery",
    ],
  },
  {
    id: "standard",
    name: "CV + Cover Letter",
    price: 80,
    popular: true,
    features: [
      "Professional CV",
      "Custom Cover Letter",
      "AI Content Optimization",
      "Priority Support",
    ],
  },
  {
    id: "premium",
    name: "Premium Package",
    price: 120,
    features: [
      "Professional CV",
      "Custom Cover Letter",
      "LinkedIn Profile Optimization",
      "Unlimited Revisions (7 days)",
    ],
  },
];

export default function Checkout() {
  const [selectedPackage, setSelectedPackage] = useState("standard");
  const { toast } = useToast();

  const selectedPkg = packages.find((pkg) => pkg.id === selectedPackage);

  const createCVMutation = useMutation({
    mutationFn: async (cvData: any) => {
      return await apiRequest("/api/cv-data", {
        method: "POST",
        body: JSON.stringify(cvData),
        headers: { "Content-Type": "application/json" },
      });
    },
  });

  const initializePaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      return await apiRequest("/api/payment/initialize", {
        method: "POST",
        body: JSON.stringify(paymentData),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: (data: any) => {
      if (data.authorizationUrl) {
        window.location.href = data.authorizationUrl;
      } else {
        toast({
          title: "Error",
          description: "Failed to initialize payment. Please try again.",
          variant: "destructive",
        });
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePayment = async () => {
    try {
      // Get CV data from localStorage
      const cvDataString = localStorage.getItem("cvData");
      const selectedTemplate = localStorage.getItem("selectedTemplate");

      if (!cvDataString) {
        toast({
          title: "Error",
          description: "CV data not found. Please create your CV first.",
          variant: "destructive",
        });
        return;
      }

      if (!selectedTemplate) {
        toast({
          title: "Error",
          description: "Please select a template first.",
          variant: "destructive",
        });
        return;
      }

      const cvData = JSON.parse(cvDataString);

      // First, save CV data to database
      const savedCV = await createCVMutation.mutateAsync(cvData);

      // Then initialize payment with CV data ID
      await initializePaymentMutation.mutateAsync({
        packageType: selectedPackage,
        amount: selectedPkg?.price,
        cvDataId: savedCV.id,
        selectedTemplate,
      });
    } catch (error) {
      console.error("Error during payment:", error);
    }
  };

  const isProcessing = createCVMutation.isPending || initializePaymentMutation.isPending;

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-6xl mx-auto px-4 md:px-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Complete Your Order</h1>
          <p className="text-muted-foreground">Choose your package and proceed to payment</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Packages */}
          <div className="lg:col-span-2 space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              {packages.map((pkg) => (
                <Card
                  key={pkg.id}
                  className={`p-6 cursor-pointer transition-all relative ${
                    selectedPackage === pkg.id
                      ? "ring-2 ring-primary"
                      : "hover-elevate"
                  }`}
                  onClick={() => setSelectedPackage(pkg.id)}
                  data-testid={`card-package-${pkg.id}`}
                >
                  {pkg.popular && (
                    <Badge className="absolute -top-3 left-1/2 -translate-x-1/2" data-testid="badge-popular">
                      Most Popular
                    </Badge>
                  )}
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold">{pkg.name}</h3>
                      <div className="text-2xl font-bold mt-2">
                        GH₵{pkg.price}
                      </div>
                    </div>
                    <ul className="space-y-2">
                      {pkg.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm">
                          <Check className="w-4 h-4 text-primary flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              ))}
            </div>

            {/* Security Badges */}
            <Card className="p-6">
              <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  <span>Secure Payment</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock className="w-5 h-5 text-primary" />
                  <span>256-bit SSL</span>
                </div>
                <div className="flex items-center gap-2">
                  <img src="https://paystack.com/assets/img/icons/paystack-icon.svg" alt="Paystack" className="w-5 h-5" />
                  <span>Powered by Paystack</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="p-6 space-y-6 sticky top-6">
              <div>
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Package</span>
                    <span className="font-medium">{selectedPkg?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Template</span>
                    <span className="font-medium">Selected</span>
                  </div>
                  <div className="border-t pt-3 flex justify-between text-lg font-semibold">
                    <span>Total</span>
                    <span>GH₵{selectedPkg?.price}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Button
                  className="w-full"
                  size="lg"
                  onClick={handlePayment}
                  disabled={isProcessing}
                  data-testid="button-proceed-payment"
                >
                  {isProcessing ? "Processing..." : "Proceed to Payment"}
                </Button>
                
                <div className="text-xs text-center text-muted-foreground">
                  <p>By proceeding, you agree to our terms of service</p>
                  <p className="mt-1">Your CV will be delivered within 3-5 minutes</p>
                </div>
              </div>

              <div className="pt-4 border-t space-y-2">
                <h3 className="font-semibold text-sm">What happens next?</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Complete secure payment via Paystack</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>AI optimizes your CV content</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Receive your professional CV via email</span>
                  </li>
                </ul>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
