import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Check, Plus, Trash2, HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { WorkExperience, Education } from "@shared/schema";
import { nanoid } from "nanoid";
import { useLocation } from "wouter";

const steps = [
  { id: 1, title: "Personal Info", description: "Basic information" },
  { id: 2, title: "Experience", description: "Work history" },
  { id: 3, title: "Education & Skills", description: "Academic background" },
  { id: 4, title: "Template", description: "Choose design" },
];

const personalInfoSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Valid phone number is required"),
  location: z.string().optional(),
  website: z.string().url().optional().or(z.literal("")),
  linkedin: z.string().url().optional().or(z.literal("")),
  github: z.string().url().optional().or(z.literal("")),
  summary: z.string().min(50, "Professional summary should be at least 50 characters").optional().or(z.literal("")),
});

export default function CreateCV() {
  const [currentStep, setCurrentStep] = useState(1);
  const [, navigate] = useLocation();
  const [workExperience, setWorkExperience] = useState<WorkExperience[]>([]);
  const [education, setEducation] = useState<Education[]>([]);
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState("");

  const form = useForm({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      location: "",
      website: "",
      linkedin: "",
      github: "",
      summary: "",
    },
  });

  const progress = (currentStep / steps.length) * 100;

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const addWorkExperience = () => {
    setWorkExperience([
      ...workExperience,
      {
        id: nanoid(),
        company: "",
        position: "",
        startDate: "",
        endDate: "",
        current: false,
        description: "",
      },
    ]);
  };

  const removeWorkExperience = (id: string) => {
    setWorkExperience(workExperience.filter((exp) => exp.id !== id));
  };

  const updateWorkExperience = (id: string, field: keyof WorkExperience, value: any) => {
    setWorkExperience(
      workExperience.map((exp) => (exp.id === id ? { ...exp, [field]: value } : exp))
    );
  };

  const addEducation = () => {
    setEducation([
      ...education,
      {
        id: nanoid(),
        institution: "",
        degree: "",
        field: "",
        startDate: "",
        endDate: "",
        current: false,
      },
    ]);
  };

  const removeEducation = (id: string) => {
    setEducation(education.filter((edu) => edu.id !== id));
  };

  const updateEducation = (id: string, field: keyof Education, value: any) => {
    setEducation(education.map((edu) => (edu.id === id ? { ...edu, [field]: value } : edu)));
  };

  const addSkill = () => {
    if (skillInput.trim()) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const removeSkill = (index: number) => {
    setSkills(skills.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    // Store data in localStorage for now, will connect to backend later
    const cvData = {
      ...form.getValues(),
      workExperience,
      education,
      skills,
    };
    localStorage.setItem("cvData", JSON.stringify(cvData));
    navigate("/templates");
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-4xl mx-auto px-4 md:px-6">
        {/* Progress */}
        <div className="mb-8 space-y-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Create Your CV</h1>
            <Badge variant="outline" data-testid="badge-step">
              Step {currentStep} of {steps.length}
            </Badge>
          </div>
          <Progress value={progress} className="h-2" data-testid="progress-bar" />
          <div className="flex justify-between">
            {steps.map((step) => (
              <div
                key={step.id}
                className={`text-center ${step.id <= currentStep ? "text-primary" : "text-muted-foreground"}`}
                data-testid={`step-indicator-${step.id}`}
              >
                <div className="text-xs font-medium">{step.title}</div>
                <div className="text-[10px] hidden sm:block">{step.description}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <Card className="p-6 md:p-8">
          {currentStep === 1 && (
            <Form {...form}>
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-semibold mb-1">Personal Information</h2>
                  <p className="text-sm text-muted-foreground">Tell us about yourself</p>
                </div>

                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Full Name <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} data-testid="input-full-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          Email <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john@example.com" {...field} data-testid="input-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          Phone <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input placeholder="+233 123 456 7890" {...field} data-testid="input-phone" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="Accra, Ghana" {...field} data-testid="input-location" />
                      </FormControl>
                      <FormDescription>City, Country</FormDescription>
                    </FormItem>
                  )}
                />

                <div className="grid md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="website"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Website</FormLabel>
                        <FormControl>
                          <Input placeholder="https://..." {...field} data-testid="input-website" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="linkedin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>LinkedIn</FormLabel>
                        <FormControl>
                          <Input placeholder="https://linkedin.com/in/..." {...field} data-testid="input-linkedin" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="github"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>GitHub</FormLabel>
                        <FormControl>
                          <Input placeholder="https://github.com/..." {...field} data-testid="input-github" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="summary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        Professional Summary
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <HelpCircle className="w-4 h-4 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">A brief overview of your professional background, key skills, and career objectives. This appears at the top of your CV.</p>
                          </TooltipContent>
                        </Tooltip>
                      </FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Experienced software engineer with 5+ years in full-stack development..."
                          className="min-h-32"
                          {...field}
                          data-testid="input-summary"
                        />
                      </FormControl>
                      <FormDescription>Briefly describe your professional background and goals (optional)</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold mb-1">Work Experience</h2>
                  <p className="text-sm text-muted-foreground">Add your professional experience</p>
                </div>
                <Button onClick={addWorkExperience} size="sm" data-testid="button-add-experience">
                  <Plus className="w-4 h-4 mr-1" />
                  Add Experience
                </Button>
              </div>

              {workExperience.length === 0 && (
                <Card className="p-12 text-center border-dashed">
                  <p className="text-muted-foreground">No work experience added yet. Click "Add Experience" to get started.</p>
                </Card>
              )}

              {workExperience.map((exp, index) => (
                <Card key={exp.id} className="p-6 space-y-4" data-testid={`card-experience-${index}`}>
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">Experience #{index + 1}</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeWorkExperience(exp.id)}
                      data-testid={`button-remove-experience-${index}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Company</label>
                      <Input
                        value={exp.company}
                        onChange={(e) => updateWorkExperience(exp.id, "company", e.target.value)}
                        placeholder="Company Name"
                        data-testid={`input-company-${index}`}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Position</label>
                      <Input
                        value={exp.position}
                        onChange={(e) => updateWorkExperience(exp.id, "position", e.target.value)}
                        placeholder="Job Title"
                        data-testid={`input-position-${index}`}
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Start Date</label>
                      <Input
                        type="month"
                        value={exp.startDate}
                        onChange={(e) => updateWorkExperience(exp.id, "startDate", e.target.value)}
                        data-testid={`input-start-date-${index}`}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">End Date</label>
                      <Input
                        type="month"
                        value={exp.endDate}
                        onChange={(e) => updateWorkExperience(exp.id, "endDate", e.target.value)}
                        disabled={exp.current}
                        data-testid={`input-end-date-${index}`}
                      />
                      <label className="flex items-center gap-2 mt-2">
                        <input
                          type="checkbox"
                          checked={exp.current}
                          onChange={(e) => updateWorkExperience(exp.id, "current", e.target.checked)}
                          data-testid={`checkbox-current-${index}`}
                        />
                        <span className="text-sm">I currently work here</span>
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Description</label>
                    <Textarea
                      value={exp.description}
                      onChange={(e) => updateWorkExperience(exp.id, "description", e.target.value)}
                      placeholder="Describe your responsibilities and achievements..."
                      className="min-h-24"
                      data-testid={`input-description-${index}`}
                    />
                  </div>
                </Card>
              ))}
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-8">
              {/* Education */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-semibold mb-1">Education</h2>
                    <p className="text-sm text-muted-foreground">Add your educational background</p>
                  </div>
                  <Button onClick={addEducation} size="sm" data-testid="button-add-education">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Education
                  </Button>
                </div>

                {education.length === 0 && (
                  <Card className="p-12 text-center border-dashed">
                    <p className="text-muted-foreground">No education added yet. Click "Add Education" to get started.</p>
                  </Card>
                )}

                {education.map((edu, index) => (
                  <Card key={edu.id} className="p-6 space-y-4" data-testid={`card-education-${index}`}>
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">Education #{index + 1}</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeEducation(edu.id)}
                        data-testid={`button-remove-education-${index}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Institution</label>
                        <Input
                          value={edu.institution}
                          onChange={(e) => updateEducation(edu.id, "institution", e.target.value)}
                          placeholder="University Name"
                          data-testid={`input-institution-${index}`}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Degree</label>
                        <Input
                          value={edu.degree}
                          onChange={(e) => updateEducation(edu.id, "degree", e.target.value)}
                          placeholder="Bachelor's, Master's, etc."
                          data-testid={`input-degree-${index}`}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium">Field of Study</label>
                      <Input
                        value={edu.field}
                        onChange={(e) => updateEducation(edu.id, "field", e.target.value)}
                        placeholder="Computer Science, Business, etc."
                        data-testid={`input-field-${index}`}
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Start Date</label>
                        <Input
                          type="month"
                          value={edu.startDate}
                          onChange={(e) => updateEducation(edu.id, "startDate", e.target.value)}
                          data-testid={`input-edu-start-${index}`}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">End Date</label>
                        <Input
                          type="month"
                          value={edu.endDate}
                          onChange={(e) => updateEducation(edu.id, "endDate", e.target.value)}
                          disabled={edu.current}
                          data-testid={`input-edu-end-${index}`}
                        />
                        <label className="flex items-center gap-2 mt-2">
                          <input
                            type="checkbox"
                            checked={edu.current}
                            onChange={(e) => updateEducation(edu.id, "current", e.target.checked)}
                            data-testid={`checkbox-edu-current-${index}`}
                          />
                          <span className="text-sm">I currently study here</span>
                        </label>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Skills */}
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-semibold mb-1">Skills</h2>
                  <p className="text-sm text-muted-foreground">Add your professional skills</p>
                </div>

                <div className="flex gap-2">
                  <Input
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    placeholder="e.g., JavaScript, Project Management"
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addSkill();
                      }
                    }}
                    data-testid="input-skill"
                  />
                  <Button onClick={addSkill} data-testid="button-add-skill">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                {skills.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="px-3 py-1" data-testid={`badge-skill-${index}`}>
                        {skill}
                        <button
                          onClick={() => removeSkill(index)}
                          className="ml-2 hover:text-destructive"
                          data-testid={`button-remove-skill-${index}`}
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-1">Choose Your Template</h2>
                <p className="text-sm text-muted-foreground">Select a professional template for your CV</p>
              </div>
              <p className="text-center text-muted-foreground py-12">Template selection will be available in the next step</p>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between pt-6 border-t mt-8">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 1}
              data-testid="button-back"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back
            </Button>

            {currentStep < steps.length ? (
              <Button onClick={handleNext} data-testid="button-next">
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            ) : (
              <Button onClick={handleSubmit} data-testid="button-submit">
                <Check className="w-4 h-4 mr-1" />
                Continue to Templates
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
