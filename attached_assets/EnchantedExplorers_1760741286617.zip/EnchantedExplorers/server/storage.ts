// Database storage implementation using Drizzle ORM
import {
  users,
  cvData,
  orders,
  templates,
  type User,
  type UpsertUser,
  type CVData,
  type InsertCVData,
  type Order,
  type InsertOrder,
  type Template,
  type InsertTemplate,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // CV Data operations
  createCVData(cvDataInput: InsertCVData): Promise<CVData>;
  getCVData(id: string): Promise<CVData | undefined>;
  getCVDataByUserId(userId: string): Promise<CVData[]>;
  updateCVData(id: string, cvDataInput: Partial<InsertCVData>): Promise<CVData>;
  
  // Order operations
  createOrder(orderInput: InsertOrder): Promise<Order>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrdersByUserId(userId: string): Promise<Order[]>;
  updateOrder(id: string, orderInput: Partial<Order>): Promise<Order>;
  updateOrderPaymentStatus(id: string, reference: string, status: string): Promise<Order>;
  updateOrderGenerationStatus(id: string, status: string, data?: any): Promise<Order>;
  
  // Template operations
  getAllTemplates(): Promise<Template[]>;
  getTemplate(id: string): Promise<Template | undefined>;
  createTemplate(templateInput: InsertTemplate): Promise<Template>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // CV Data operations
  async createCVData(cvDataInput: InsertCVData): Promise<CVData> {
    const [cv] = await db.insert(cvData).values(cvDataInput).returning();
    return cv;
  }

  async getCVData(id: string): Promise<CVData | undefined> {
    const [cv] = await db.select().from(cvData).where(eq(cvData.id, id));
    return cv;
  }

  async getCVDataByUserId(userId: string): Promise<CVData[]> {
    return await db
      .select()
      .from(cvData)
      .where(eq(cvData.userId, userId))
      .orderBy(desc(cvData.createdAt));
  }

  async updateCVData(id: string, cvDataInput: Partial<InsertCVData>): Promise<CVData> {
    const [cv] = await db
      .update(cvData)
      .set({ ...cvDataInput, updatedAt: new Date() })
      .where(eq(cvData.id, id))
      .returning();
    return cv;
  }

  // Order operations
  async createOrder(orderInput: InsertOrder): Promise<Order> {
    const [order] = await db.insert(orders).values(orderInput).returning();
    return order;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async getOrdersByUserId(userId: string): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async updateOrder(id: string, orderInput: Partial<Order>): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set({ ...orderInput, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return order;
  }

  async updateOrderPaymentStatus(id: string, reference: string, status: string): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set({
        paystackReference: reference,
        paymentStatus: status,
        updatedAt: new Date(),
      })
      .where(eq(orders.id, id))
      .returning();
    return order;
  }

  async updateOrderGenerationStatus(id: string, status: string, data?: any): Promise<Order> {
    const updateData: any = {
      generationStatus: status,
      updatedAt: new Date(),
    };
    
    if (data) {
      if (data.optimizedContent) updateData.optimizedContent = data.optimizedContent;
      if (data.cvFileUrl) updateData.cvFileUrl = data.cvFileUrl;
      if (data.coverLetterFileUrl) updateData.coverLetterFileUrl = data.coverLetterFileUrl;
    }

    const [order] = await db
      .update(orders)
      .set(updateData)
      .where(eq(orders.id, id))
      .returning();
    return order;
  }

  // Template operations
  async getAllTemplates(): Promise<Template[]> {
    return await db.select().from(templates).where(eq(templates.isActive, 'true'));
  }

  async getTemplate(id: string): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    return template;
  }

  async createTemplate(templateInput: InsertTemplate): Promise<Template> {
    const [template] = await db.insert(templates).values(templateInput).returning();
    return template;
  }
}

export const storage = new DatabaseStorage();
