import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertCVDataSchema } from "@shared/schema";
import OpenAI from "openai";
import axios from "axios";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// Initialize Paystack
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY!;
const PAYSTACK_BASE_URL = "https://api.paystack.co";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // CV Data routes
  app.post("/api/cv-data", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertCVDataSchema.parse({
        ...req.body,
        userId,
      });
      
      const cvData = await storage.createCVData(validatedData);
      res.json(cvData);
    } catch (error: any) {
      console.error("Error creating CV data:", error);
      res.status(400).json({ message: error.message || "Failed to create CV data" });
    }
  });

  app.get("/api/cv-data", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cvDataList = await storage.getCVDataByUserId(userId);
      res.json(cvDataList);
    } catch (error) {
      console.error("Error fetching CV data:", error);
      res.status(500).json({ message: "Failed to fetch CV data" });
    }
  });

  app.get("/api/cv-data/:id", isAuthenticated, async (req: any, res) => {
    try {
      const cvData = await storage.getCVData(req.params.id);
      if (!cvData) {
        return res.status(404).json({ message: "CV data not found" });
      }
      res.json(cvData);
    } catch (error) {
      console.error("Error fetching CV data:", error);
      res.status(500).json({ message: "Failed to fetch CV data" });
    }
  });

  // AI CV Optimization endpoint
  app.post("/api/optimize-cv", isAuthenticated, async (req: any, res) => {
    try {
      const { cvData } = req.body;

      // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      const completion = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `You are an expert CV writer and ATS optimization specialist. Your task is to:
1. Polish and enhance the professional summary
2. Improve work experience descriptions using strong action verbs and quantifiable achievements
3. Ensure ATS compatibility by using industry-standard keywords
4. Maintain professional tone and formatting
5. Return a JSON object with optimized content

Return format:
{
  "summary": "enhanced professional summary",
  "workExperience": [{ "id": "...", "description": "enhanced description", ...other fields unchanged }],
  "suggestions": ["suggestion 1", "suggestion 2"]
}`,
          },
          {
            role: "user",
            content: JSON.stringify(cvData),
          },
        ],
        max_completion_tokens: 8192,
      });

      const optimizedContent = JSON.parse(completion.choices[0].message.content || "{}");
      res.json({ optimizedContent });
    } catch (error: any) {
      console.error("Error optimizing CV:", error);
      res.status(500).json({ message: "Failed to optimize CV", error: error.message });
    }
  });

  // Paystack payment initialization
  app.post("/api/payment/initialize", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { packageType, amount, cvDataId, selectedTemplate } = req.body;

      // Create order first
      const order = await storage.createOrder({
        userId,
        cvDataId,
        packageType,
        amount: amount * 100, // Convert to kobo/cents
        currency: 'GHS',
        selectedTemplate,
      });

      // Initialize Paystack payment
      const paystackResponse = await axios.post(
        `${PAYSTACK_BASE_URL}/transaction/initialize`,
        {
          email: req.user.claims.email || 'customer@devignite.com',
          amount: amount * 100, // Amount in kobo (GHS cents)
          currency: 'GHS',
          reference: order.id,
          callback_url: `${req.protocol}://${req.hostname}/api/payment/verify?reference=${order.id}`,
          metadata: {
            orderId: order.id,
            userId,
            packageType,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (paystackResponse.data.status) {
        await storage.updateOrderPaymentStatus(
          order.id,
          order.id,
          'pending'
        );

        res.json({
          authorizationUrl: paystackResponse.data.data.authorization_url,
          reference: order.id,
        });
      } else {
        res.status(400).json({ message: "Failed to initialize payment" });
      }
    } catch (error: any) {
      console.error("Error initializing payment:", error);
      res.status(500).json({ 
        message: "Failed to initialize payment", 
        error: error.response?.data || error.message 
      });
    }
  });

  // Paystack payment verification
  app.get("/api/payment/verify", async (req: any, res) => {
    try {
      const { reference } = req.query;

      if (!reference) {
        return res.status(400).json({ message: "No reference provided" });
      }

      // Verify payment with Paystack
      const paystackResponse = await axios.get(
        `${PAYSTACK_BASE_URL}/transaction/verify/${reference}`,
        {
          headers: {
            Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
          },
        }
      );

      if (paystackResponse.data.status && paystackResponse.data.data.status === 'success') {
        // Update order payment status
        const order = await storage.updateOrderPaymentStatus(
          reference as string,
          paystackResponse.data.data.reference,
          'success'
        );

        // Start CV generation process
        await storage.updateOrderGenerationStatus(order.id, 'processing');

        // Trigger CV generation in background (simplified for now)
        processCVGeneration(order.id).catch(console.error);

        // Redirect to dashboard
        res.redirect('/');
      } else {
        await storage.updateOrderPaymentStatus(reference as string, reference as string, 'failed');
        res.redirect('/?payment=failed');
      }
    } catch (error: any) {
      console.error("Error verifying payment:", error);
      res.redirect('/?payment=error');
    }
  });

  // Orders routes
  app.get("/api/orders", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrders = await storage.getOrdersByUserId(userId);
      res.json(userOrders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", isAuthenticated, async (req: any, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  // Templates routes
  app.get("/api/templates", async (req, res) => {
    try {
      const templatesList = await storage.getAllTemplates();
      res.json(templatesList);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Background CV generation process
async function processCVGeneration(orderId: string) {
  try {
    const order = await storage.getOrder(orderId);
    if (!order) return;

    const cvData = await storage.getCVData(order.cvDataId);
    if (!cvData) return;

    // Optimize CV with AI
    const completion = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert CV writer. Optimize the following CV for ATS and professional presentation.",
        },
        {
          role: "user",
          content: JSON.stringify(cvData),
        },
      ],
      max_completion_tokens: 8192,
    });

    const optimizedContent = JSON.parse(completion.choices[0].message.content || "{}");

    // Update order with optimized content (PDF generation would go here)
    await storage.updateOrderGenerationStatus(orderId, 'completed', {
      optimizedContent,
      cvFileUrl: 'https://example.com/cv.pdf', // Placeholder - would be actual PDF URL
    });

    // Send email notification (would use nodemailer here)
    console.log(`CV generated for order ${orderId}`);
  } catch (error) {
    console.error("Error generating CV:", error);
    await storage.updateOrderGenerationStatus(orderId, 'failed');
  }
}
